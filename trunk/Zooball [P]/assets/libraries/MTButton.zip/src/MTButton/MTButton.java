package MTButton;
/*
  Multi-Touch Button Class.
  
  (c) copyright
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
 */

import processing.core.*;

/**
 * ---------------------------------------------
 * Button.pde
 *
 * Description: Simple button class. Either uses a rectangular image or a basic circle
 *
 * Class: CS 426 Spring 2009
 * System: Processing 1.0.1, Windows XP SP2/Windows Vista
 * Author: Arthur Nishimoto
 * Version: 0.3.1
 * 
 * Version Notes:
 * 2/6/09    - Initial version
 * 3/28/09   - Added button text
 * 4/1/09    - Support for rectangular buttons
 *           - Button text displays up and down
 * 4/4/09    - Added a lit state
 * 4/26/09   - Version 0.2
 *           - Added litImage and rotation for circle, rect, and images. (hitBox does not rotate)
 * 4/29/09   - Font size added.
 * 6/1/09    - Version 0.2.1
 *           - Added push delay to allow a hold-press
 * 6/4/09    - Button uses internal timer
 * 6/5/09    - Version 0.3.1
 *           - Null pointer bug fix (make sure all Processing draw functions (i.e. fill, stroke, text) point to PApplet p.
 *           - Additional support for rectangular buttons with/without images.
 * ---------------------------------------------
 */

public class MTButton extends PApplet{

	PApplet p;

	PImage buttonImage;
	float xPos, yPos;
	double buttonDownTime = 0.2;
	double buttonLastPressed = -1; // -1 allows pressed on start, 0 if delay desired
	double gameTimer;
	boolean hasImage = false;
	boolean isRound = false;
	boolean isRectangle = false;
	boolean pressed, lit;
	float diameter;
	float rHeight, rWidth;
	int idle_cl = color( 0, 0, 0 );
	int lit_cl = color( 255, 255, 255 );
	int pressed_cl = color( 255, 0, 0);
	float angle = 0;
	int fontSize = 16;
    float rotation = 0;

	boolean hasLitImage = false;
	PImage litImage;
	  
	boolean hasPressedImage = false;
	PImage pressedImage;
	    
	    
	boolean active;
	String buttonText = "";
	int buttonTextColor = color(0,0,0);
	boolean doubleSidedText = true;
	boolean invertText = false;
	  
	int fadeAmount = 1;
	int fadeSpeed = 5;
	boolean fadeIn, fadeOut;
	int fadeColor = color(0,0,0);
	boolean fadeEnable = false;
	boolean doneFading = true;
	  
	boolean delayedPress = true;
	float delayCounter = 0;
	float delayIncrement = 1;
	float delayTrigger = 100;
	int holdStyle = 0;
	PFont font = loadFont("CourierNew36.vlw");

	public final String VERSION = "0.3.1";

	/**
	 * a Constructor, usually called in the setup() method in your sketch to
	 * initialize and start the library.
	 * 
	 * @example Hello
	 * @param theParent
	 */
	public MTButton(PApplet theParent) {
		p = theParent;
	}

	/**
	 * return the version of the library.
	 * 
	 * @return String
	 */
	public String version() {
		return VERSION;
	}
	
	/**
	 * Creates a new round button, (x,y) is center.
     *
	 * @param new_xPos - x position
	 * @param new_yPos - y position
	 * @param newDia   - diameter
	 */
	public MTButton( int new_xPos, int new_yPos, float newDia ){
	  diameter = newDia;
	  xPos = new_xPos;
	  yPos = new_yPos;
	  isRound = true;
	}// Button CTOR

	/**
	 * Creates a new round button, (x,y) is center. Used when button is not created
	 * inside the parent Processing class.
     *
     * @param parent PApplet parent where draw() is called
	 * @param new_xPos x position
	 * @param new_yPos y position
	 * @param newDia diameter
	 */
	public MTButton( PApplet parent, int new_xPos, int new_yPos, float newDia ){
	  p = parent;
	  diameter = newDia;
	  xPos = new_xPos;
	  yPos = new_yPos;
	  isRound = true;
	}// Button CTOR
	
	/**
	 * Creates a new rectangular button, (x,y) is center.
	 *
	 * @param new_xPos  - x position
	 * @param new_yPos  - y position
	 * @param newWidth  - width
	 * @param newHeight - height
	 */
	public MTButton( int new_xPos, int new_yPos, float newWidth, float newHeight ){
	  rWidth = newWidth;
	  rHeight = newHeight;
	  xPos = new_xPos;
	  yPos = new_yPos;
	  isRectangle = true;
	}// Button CTOR
	
	/**
	 * Creates a new rectangular button, (x,y) is center.
	 * Used when button is not created inside the parent Processing class.
	 *
	 * @param parent PApplet parent where draw() is called
	 * @param new_xPos x position
	 * @param new_yPos y position
	 * @param newWidth  - width
	 * @param newHeight - height
	 */
	public MTButton( PApplet parent, int new_xPos, int new_yPos, float newWidth, float newHeight ){
	  p = parent;
	  rWidth = newWidth;
	  rHeight = newHeight;
	  xPos = new_xPos;
	  yPos = new_yPos;
	  isRectangle = true;
	}// Button CTOR
	
	/**
	 * Creates a new rectangular button with an image, (x,y) is center.
	 *
	 * @param new_xPos  - x position
	 * @param new_yPos  - y position
	 * @param newImage  - File path and name of image
	 */  
	public MTButton( int new_xPos, int new_yPos, String newImage ){
	  buttonImage = loadImage(newImage);
	  xPos = new_xPos;
	  yPos = new_yPos;
	  diameter = buttonImage.width;
	  hasImage = true;
	}// Button CTOR

	/**
	 * Creates a new rectangular button with an image, (x,y) is center.
	 * Used when button is not created inside the parent Processing class.
	 *
	 * @param parent PApplet parent where draw() is called
	 * @param new_xPos x position
	 * @param new_yPos y position
	 * @param newImage PImage to be displayed as idle image
	 */  
	public MTButton( PApplet parent, int new_xPos, int new_yPos, PImage newImage ){
	  p = parent;
	  buttonImage = newImage;
	  xPos = new_xPos;
	  yPos = new_yPos;
	  diameter = buttonImage.width;
	  hasImage = true;
	}// Button CTOR
	
	/**
	 * Sets button active, displays, updates timer.
	 * Uses internal Processing timer.
	 * @param font Font the button will use to display text. If null, button has a default font.
	 */
	public void process(PFont font){
	  if(hasImage)
	    displayImage();
	  else
	    display(font);
	  displayText();
	  //displayDebug(color(0,255,0), font);
	  //displayEdges(color(255,255,255));
	  setGameTimer(1000*(double)millis());
	}// process
	
	/**
	 * Sets button active, displays, updates timer.
	 * @param font Font the button will use to display text. If null, button has a default font.
	 * @param timer_g The timer used for determining press time. Taken from the game loop.
	 */
	public void process(PFont font, double timer_g){
	  if(hasImage)
	    displayImage();
	  else
	    display(font);
	  displayText();
	  //displayDebug(color(0,255,0), font);
	  //displayEdges(color(255,255,255));
	  setGameTimer(timer_g);
	}// process
	
	/**
	 * Sets button active, displays, updates timer.
	 */
	public void process(){
	  if(hasImage)
	    displayImage();
	  else
	    display(font);
	  displayText();
	  //displayDebug(color(0,255,0), font);
	  //displayEdges(color(255,255,255));
	  //setGameTimer(timer_g);
	}// process
	
	private void displayImage(){
	  if( fadeAmount <= 1 )
	    active = true;
	    
	  p.imageMode(CENTER);
	  p.pushMatrix();
	  p.translate(xPos, yPos);
	  p.rotate( rotation );
	  
	  p.image( buttonImage, 0, 0);
	  if( hasLitImage && lit )
	    p.image( litImage, 0, 0 );
	  if( hasPressedImage && pressed )
	    p.image( pressedImage, 0, 0 );
	    
	  p.popMatrix();
	  p.imageMode(CORNER);
	}// displayImage
	 
	private void displayText(){
	  p.pushMatrix();
	  p.translate(xPos, yPos);
	  p.rotate( rotation );
	  
	  
	  p.fill(buttonTextColor);
	  p.textFont(font,fontSize);
	  p.textAlign(CENTER);
	
	  int textShift = 0;
	  if( doubleSidedText )
	    textShift = fontSize;
	  
	  if( doubleSidedText || !invertText ){
	    p.text(buttonText, 0, 0 + textShift);
	  }// if text not inverted
	    
	    if( doubleSidedText || invertText ){
	      p.translate(0, 0 - textShift);
	      p.rotate(radians(180));
	      p.text(buttonText, 0, 0);  
	      
	    }// if doubleSidedtext
	    p.textAlign(LEFT);
	    p.popMatrix();
	  }// displayText
	  
	  private void display(PFont font){
	    p.rectMode(CENTER);
	    p.pushMatrix();
	    p.translate(xPos, yPos);
	    p.rotate( rotation );
	    
	    if( fadeAmount <= 1 )
	      active = true;
	    
	    if(!pressed && !lit){
	      p.fill(idle_cl);
	      p.stroke(idle_cl);
	      if(isRound)
	        p.ellipse( 0, 0, diameter, diameter );
	      else if(isRectangle)
	        p.rect( 0, 0, rWidth, rHeight );
	    }else if(lit){
	      p.fill(lit_cl);
	      p.stroke(lit_cl);
	      if(isRound)
	        p.ellipse( 0, 0, diameter, diameter );
	      else if(isRectangle)
	        p.rect( 0, 0, rWidth, rHeight );
	    }else if(pressed){
	      p.fill(pressed_cl);
	      p.stroke(pressed_cl);
	      if(isRound)
	        p.ellipse( 0, 0, diameter, diameter );
	      else if(isRectangle)
	        p.rect( 0, 0, rWidth, rHeight );
	    }
	    
	    if(delayedPress){
	      displayHold();
	    }// if delayed press
	    
	    p.popMatrix();
	    p.rectMode(CORNER);

	    if(fadeEnable){
	      if(fadeIn && fadeAmount > 0)
	        fadeAmount -= fadeSpeed;
	      else if(fadeOut && fadeAmount < 256)
	        fadeAmount += fadeSpeed;
	      else
	        doneFading = true;
	    }// if fadeEnable
	    
	    p.fill(fadeColor,fadeAmount);
	    p.noStroke();
	    if(hasImage)
	      p.rect( xPos, yPos, buttonImage.width, buttonImage.height );
	    if(isRectangle)
	      p.rect( xPos, yPos, rWidth, rHeight );
	    if(isRound)
	      p.ellipse( xPos, yPos, diameter, diameter );
	  }// display
	  
	  /**
	   * Displays the hitbox edges of button
	   *
	   * @param debugColor - color of edges
	   */
	  public void displayEdges(int debugColor){
	    p.fill(debugColor);

	    if(isRound){
	      p.ellipse( xPos-diameter/2, yPos-diameter/2, 10, 10 ); // Top left
	      p.ellipse( xPos+diameter/2, yPos-diameter/2, 10, 10 ); // Top Right
	      p.ellipse( xPos-diameter/2, yPos+diameter/2, 10, 10 ); // Bottom left
	      p.ellipse( xPos+diameter/2, yPos+diameter/2, 10, 10 ); // Bottom Right      
	    }else if(hasImage){
	      p.ellipse( xPos-buttonImage.width/2, yPos-buttonImage.height/2, 10, 10 ); // Top left
	      p.ellipse( xPos+buttonImage.width/2, yPos+buttonImage.height/2, 10, 10 ); // Bottom Right
	      p.ellipse( xPos+buttonImage.width/2, yPos-buttonImage.height/2 , 10, 10 ); // Top right
	      p.ellipse( xPos-buttonImage.width/2, yPos+buttonImage.height/2, 10, 10 );// Bottom Left 
	    }else if(isRectangle){
	      p.ellipse( xPos-rWidth/2, yPos-rHeight/2, 10, 10 ); // Top left
	      p.ellipse( xPos+rWidth/2, yPos+rHeight/2, 10, 10 ); // Bottom Right
	      p.ellipse( xPos+rWidth/2, yPos-rHeight/2 , 10, 10 ); // Top right
	      p.ellipse( xPos-rWidth/2, yPos+rHeight/2, 10, 10 );// Bottom Left    
	    }
	  }//  displayEdges
	  
	  public void displayDebug(int debugColor, PFont font){
	    p.fill(debugColor);
	    p.textFont(font,16);

	    p.text("Pressed: "+pressed, xPos+diameter, yPos-diameter/2);
	    p.text("Button Delay: "+buttonDownTime, xPos+diameter, yPos-diameter/2+16);
	    p.text("Delay Counter: "+100*(delayCounter/delayTrigger), xPos+diameter, yPos-diameter/2+16*3);
	    if(buttonLastPressed + buttonDownTime > gameTimer)
	      p.text("Button Downtime Remain: "+((buttonLastPressed + buttonDownTime)-gameTimer), xPos+diameter, yPos-diameter/2+16*2);
	    else
	      p.text("Button Downtime Remain: 0", xPos+diameter, yPos-diameter/2+16*2);
	  }// displayDebug
	    
	  public boolean isHit( float xCoord, float yCoord ){
	    if( !active || fadeAmount > 1 )
	      return false;

	    if(isRound){
	      if( xCoord > xPos-diameter/2 && xCoord < xPos+diameter/2 && yCoord > yPos-diameter/2 && yCoord < yPos+diameter/2){
	        if(delayedPress){
	          if( delayCounter >= delayTrigger ){
	            pressed = true;
	            return true;
	          }else{
	            delayCounter += delayIncrement;
	            return false;
	          }
	        }
	        if (buttonLastPressed == 0){
	          buttonLastPressed = gameTimer;
	        }else if ( buttonLastPressed + buttonDownTime < gameTimer){
	          buttonLastPressed = gameTimer;
	          pressed = true;
	          return true;
	        }// if-else-if button pressed
	      }// if x, y in area
	    }else if(hasImage){
	      if( xCoord > xPos-buttonImage.width/2 && xCoord < xPos+buttonImage.width/2 && yCoord > yPos - buttonImage.height/2  && yCoord < yPos+buttonImage.height/2){
	        if (buttonLastPressed == 0){
	          buttonLastPressed = gameTimer;
	        }else if ( buttonLastPressed + buttonDownTime < gameTimer){
	          buttonLastPressed = gameTimer;
	          pressed = true;
	          return true;
	        }// if-else-if button pressed
	      }// if x, y in area
	    }else if(isRectangle){
	       if( xCoord > xPos-rWidth/2 && xCoord < xPos+rWidth/2 && yCoord > yPos - rHeight/2  && yCoord < yPos+rHeight/2){
	        if (buttonLastPressed == 0){
	          buttonLastPressed = gameTimer;
	        }else if ( buttonLastPressed + buttonDownTime < gameTimer){
	          buttonLastPressed = gameTimer;
	          pressed = true;
	          return true;
	        }// if-else-if button pressed
	      }// if x, y in area     
	    }
	    delayCounter = 0;
	    pressed = false;
	    return false;
	  }// isHit
	  
	  private void displayHold(){
	    switch(holdStyle){
	      case(0):
	        p.fill(pressed_cl);
	        p.noStroke();
	        if(isRound)
	          p.ellipse( 0, 0, delayCounter, delayCounter );
	        break;
	      case(1):
	        p.fill(pressed_cl);
	        p.noStroke();
	        if(isRound){
	          if( delayCounter/delayTrigger > 0 )
	            p.ellipse( 0, 0-diameter/2, 10, 10 );
	          if( delayCounter/delayTrigger > 0.15 )
	            p.ellipse( 0+diameter/3, 0-diameter/3, 10, 10 );
	          if( delayCounter/delayTrigger > 0.30 )
	            p.ellipse( 0+diameter/2, 0, 10, 10 );
	          if( delayCounter/delayTrigger > 0.45 )
	            p.ellipse( 0+diameter/3, 0+diameter/3, 10, 10 );
	          if( delayCounter/delayTrigger > 0.60 )
	            p.ellipse( 0, 0+diameter/2, 10, 10 );
	          if( delayCounter/delayTrigger > 0.75 )
	            p.ellipse( 0-diameter/3, 0+diameter/3, 10, 10 );
	          if( delayCounter/delayTrigger > 0.95 )
	            p.ellipse( 0-diameter/2, 0, 10, 10 );
	          if( delayCounter/delayTrigger >= 1.0 )
	            p.ellipse( 0-diameter/3, 0-diameter/3, 10, 10 );
	        }      
	        break;
	      default:
	        println("ERROR: Unknown button hold style.");
	        break;
	    }
	  }// displayHold
	  
	  public void resetButton(){
	    delayCounter = 0;
	    pressed = false;
	  }// resetButton;
	  
	  // Setters and Getters
	  
	  public void setIdleColor(int newColor){
	    idle_cl = newColor;
	  }// setIdleColor
	  
	  public void setLitColor(int newColor){
	    lit_cl = newColor;
	  }// setLitColor

	  public void setLitImage(PImage newImage){
	    litImage = newImage;
	    hasLitImage = true;
	  }// setLitImage  
	  
	  public void setLit(boolean newBool){
	    lit = newBool;
	  }// setLit
	  
	  public void setPressedColor(int newColor){
	    pressed_cl = newColor;
	  }// setPressedColor
	  
	  public void setPressedImage(PImage newImage){
	    pressedImage = newImage;
	    hasPressedImage = true;
	  }// setPressedImage  
	  
	  public void setButtonText(String newText){
	    buttonText = newText;
	  }// setButtonText  
	  
	  public void setButtonTextSize(int newSize){
	    fontSize = newSize;
	  }// setButtonTextSize
	  
	  public void setButtonTextColor(int newColor){
	    buttonTextColor = newColor;
	  }// setButtonTextColor

	  public void setDoubleSidedText( boolean newBool ){
	    doubleSidedText = newBool;
	  }// setDoubleSidedText
	  
	  public void setInvertedText( boolean newBool ){
	    invertText = newBool;
	    doubleSidedText = !newBool;
	  }// setInvertedText
	  
	  public void setDelay(double newDelay){
	    buttonDownTime = newDelay;
	  }// setDelay
	  
	  /*
	   * If true, button can be pressed on start. Could accidently press if there are multiple buttons on the same location of adjacent screens
	   * If false, first touch on button will be ignored.
	   */
	  public void setPressOnInit( boolean bool){
	    if(bool)
	      buttonLastPressed = -1;
	    else
	      buttonLastPressed = 0;
	  }// setPressOnInit
	  
	  public void setGameTimer( double timer_g ){
	    gameTimer = timer_g;
	  }// setGameTimer

	  public void setFadeOut(){
	    fadeAmount = 1;
	    fadeOut = true;
	    fadeIn = false;
	    doneFading = false;
	  }// setFadeOut
	  
	  public void setFadeIn(){
	    fadeAmount = 255;
	    fadeOut = false;
	    fadeIn = true;
	    doneFading = false;
	  }// setFadeOut
	  
	  public void setFadeColor(int newColor){
	    fadeColor = newColor;
	  }// setFadeColor
	  
	  public void setPosition(float x, float y){
	    xPos = x;
	    yPos = y;
	  }//setPosition
	  
	  public void setRotation(float newValue){
	    rotation = newValue;
	  }// setRotation
	  
	  public void setDelayedPress(boolean bool){
	    delayedPress = bool;
	  }// setDelayedPress
	  
	  public void setDelayIncrement(float newValue){
	    delayIncrement = newValue;
	  }// setDelayIncrement
	  
	  public void setDelayTrigger(float newValue){
	    delayTrigger = newValue;
	  }// setDelayTrigger
	  
	  public void setHoldStyle(int newValue){
	    holdStyle = newValue;
	  }// setHoldStyle
	  
	  public void fadeEnable(){
	    fadeEnable = true;
	  }// fadeEnable
	  
	  public void fadeDisable(){
	    fadeEnable = true;
	  }// fadeEnable   
	 
	  public boolean isButtonActive(){
	    if(active)
	      return true;
	    else
	      return false;  
	  }// isActive
	  
	  public boolean isPressed(){
	    return pressed;
	  }// isPressed
	  
	  public boolean isLit(){
	    return lit;
	  }// isLit
	  
	  public boolean isDoneFading(){
	    return doneFading;
	  }// isDoneFading
}// MTButton class
