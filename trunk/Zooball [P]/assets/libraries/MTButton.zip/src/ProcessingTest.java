import processing.core.*;
import MTButton.*;

public class ProcessingTest extends PApplet{

	MTButton test, imageTest;
	PFont newFont; // Not necessary as of v0.3.1 unless specific font needed
	
	public void setup(){
		size( 640, 480 );
		test = new MTButton(this, 10, 10, 10);
		imageTest = new MTButton(this, 200, 200, loadImage("lev4_button.gif") );
		newFont = loadFont("CourierNew36.vlw");
	}
	
	public void draw(){
		background(50,50,50);
		fill(0,255,0);
		stroke(255,0,0);
		rect( width/2, height/2, 100, 25);
		test.process(newFont); // As of v0.3.1, just process() works
		test.setHoldStyle(1);
		imageTest.process();
		if(mousePressed){
			test.isHit(mouseX, mouseY);
		}else
			test.resetButton();
	}
	
	public static void main(String[] args){
		PApplet.main(new String[] { ProcessingTest.class.getName() });
	}// main
}// class ProcessingTest
